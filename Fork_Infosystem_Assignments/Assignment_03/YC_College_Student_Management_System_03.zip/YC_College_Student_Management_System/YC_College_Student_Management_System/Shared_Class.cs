﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace YC_College_Student_Management_System
{
    class Shared_Class
    {
        public static string Username = " ";
    }
}
